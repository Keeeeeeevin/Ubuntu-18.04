#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtSerialPort/QSerialPortInfo>
#include <QSerialPort>
#include <QMessageBox>


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_OpenSerialPort_clicked();
    void on_comboBox_SerialPort_currentTextChanged(const QString &arg1);

    void on_verticalSlider2_Thumb_sliderReleased();
    void on_verticalSlider3_Index_sliderReleased();
    void on_verticalSlider4_Mid_sliderReleased();
    void on_verticalSlider5_Ring_sliderReleased();
    void on_verticalSlider6_Little_sliderReleased();
    void on_verticalSlider7_Wrist_sliderReleased();

    void on_verticalSlider8_Elbow_sliderReleased();
    void on_verticalSlider9_Shoulder3_sliderReleased();
    void on_verticalSlider10_Shoulder2_sliderReleased();
    void on_verticalSlider11_Shoulder1_sliderReleased();

    void on_verticalSlider12_Neck1_sliderReleased();
    void on_verticalSlider13_Neck2_sliderReleased();

    void on_verticalSlider27_Lean_sliderReleased();
    void on_verticalSlider28_Rot_sliderReleased();

    void on_pushButton_CloseHand_clicked();
    void on_pushButton_OpenHand_clicked();

    void on_pushButton_Reset_clicked();

    void on_verticalSlider12_Neck1_sliderMoved(int position);

private:
    Ui::MainWindow *ui;
    QSerialPort m_SerialPort_A;
};

#endif // MAINWINDOW_H
