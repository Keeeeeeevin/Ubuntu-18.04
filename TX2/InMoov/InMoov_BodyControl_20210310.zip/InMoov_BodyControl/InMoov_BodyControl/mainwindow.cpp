#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <iostream>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    setFixedSize(this->width(),this->height());

    foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
    {
        QString s = info.portName();
        ui->comboBox_SerialPort->addItem(s);
    }
    ui->comboBox_SerialPort->addItem("Refresh");
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 打开串口
void MainWindow::on_pushButton_OpenSerialPort_clicked()
{
    if(ui->pushButton_OpenSerialPort->text() == QStringLiteral("Open Serial Port"))
    {
        QString str_port = ui->comboBox_SerialPort->currentText();

        m_SerialPort_A.setPortName("/dev/" + str_port);
        if(m_SerialPort_A.open(QIODevice::ReadWrite))
        {
            m_SerialPort_A.setBaudRate(9600);
            m_SerialPort_A.setDataBits(QSerialPort::Data8);
            m_SerialPort_A.setFlowControl(QSerialPort::NoFlowControl);
            m_SerialPort_A.setParity(QSerialPort::NoParity);
            m_SerialPort_A.setStopBits(QSerialPort::OneStop);
        }
        else
        {
            QMessageBox msgBox;
            msgBox.setText(QStringLiteral("Open Serial Port Failed"));
            msgBox.exec();
            return;
        }

        ui->pushButton_OpenSerialPort->setText(QStringLiteral("Close Serial Port"));
    }

    else if(ui->pushButton_OpenSerialPort->text() == QStringLiteral("Close Serial Port"))
    {
        m_SerialPort_A.close();
        ui->pushButton_OpenSerialPort->setText(QStringLiteral("Open Serial Port"));
    }
    else
    {
        return;
    }
}

// 刷新串口
void MainWindow::on_comboBox_SerialPort_currentTextChanged(const QString &arg1)
{
    if(arg1 == "Refresh")
    {
        ui->comboBox_SerialPort->clear();
        foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
        {
            QString s = info.portName();
            ui->comboBox_SerialPort->addItem(s);
        }
        ui->comboBox_SerialPort->addItem("Refresh");
    }
}

// 拇指
void MainWindow::on_verticalSlider2_Thumb_sliderReleased()
{
    QByteArray sendData;
    sendData[0] = 2;
    sendData[1] = ui->verticalSlider2_Thumb->value()/10.0;

    std::cout << (unsigned char)(sendData[1])*10 << std::endl;
    m_SerialPort_A.write("INM");
    m_SerialPort_A.write(sendData);
    m_SerialPort_A.write("OOV");
}

// 食指
void MainWindow::on_verticalSlider3_Index_sliderReleased()
{
    QByteArray sendData;
    sendData[0] = 3;
    sendData[1] = ui->verticalSlider3_Index->value()/10.0;

    std::cout << (unsigned char)(sendData[1])*10 << std::endl;
    m_SerialPort_A.write("INM");
    m_SerialPort_A.write(sendData);
    m_SerialPort_A.write("OOV");
}

// 中指
void MainWindow::on_verticalSlider4_Mid_sliderReleased()
{
    QByteArray sendData;
    sendData[0] = 4;
    sendData[1] = ui->verticalSlider4_Mid->value()/10.0;

    std::cout << (unsigned char)(sendData[1])*10 << std::endl;
    m_SerialPort_A.write("INM");
    m_SerialPort_A.write(sendData);
    m_SerialPort_A.write("OOV");
}

// 无名指
void MainWindow::on_verticalSlider5_Ring_sliderReleased()
{
    QByteArray sendData;
    sendData[0] = 5;
    sendData[1] = ui->verticalSlider5_Ring->value()/10.0;

    std::cout << (unsigned char)(sendData[1])*10 << std::endl;
    m_SerialPort_A.write("INM");
    m_SerialPort_A.write(sendData);
    m_SerialPort_A.write("OOV");
}

// 小指
void MainWindow::on_verticalSlider6_Little_sliderReleased()
{
    QByteArray sendData;
    sendData[0] = 6;
    sendData[1] = ui->verticalSlider6_Little->value()/10.0;

    std::cout << (unsigned char)(sendData[1])*10 << std::endl;
    m_SerialPort_A.write("INM");
    m_SerialPort_A.write(sendData);
    m_SerialPort_A.write("OOV");
}

// 手腕
void MainWindow::on_verticalSlider7_Wrist_sliderReleased()
{
    QByteArray sendData;
    sendData[0] = 7;
    sendData[1] = ui->verticalSlider7_Wrist->value()/10.0;

    std::cout << (unsigned char)(sendData[1])*10 << std::endl;
    m_SerialPort_A.write("INM");
    m_SerialPort_A.write(sendData);
    m_SerialPort_A.write("OOV");
}

// 肘
void MainWindow::on_verticalSlider8_Elbow_sliderReleased()
{
    QByteArray sendData;
    sendData[0] = 8;
    sendData[1] = ui->verticalSlider8_Elbow->value()/10.0;

    std::cout << (unsigned char)(sendData[1])*10 << std::endl;
    m_SerialPort_A.write("INM");
    m_SerialPort_A.write(sendData);
    m_SerialPort_A.write("OOV");
}

// 肩部3
void MainWindow::on_verticalSlider9_Shoulder3_sliderReleased()
{
    QByteArray sendData;
    sendData[0] = 9;
    sendData[1] = ui->verticalSlider9_Shoulder3->value()/10.0;

    std::cout << (unsigned char)(sendData[1])*10 << std::endl;
    m_SerialPort_A.write("INM");
    m_SerialPort_A.write(sendData);
    m_SerialPort_A.write("OOV");
}

// 肩部2
void MainWindow::on_verticalSlider10_Shoulder2_sliderReleased()
{
    QByteArray sendData;
    sendData[0] = 10;
    sendData[1] = ui->verticalSlider10_Shoulder2->value()/10.0;

    std::cout << (unsigned char)(sendData[1])*10 << std::endl;
    m_SerialPort_A.write("INM");
    m_SerialPort_A.write(sendData);
    m_SerialPort_A.write("OOV");
}

// 肩部1
void MainWindow::on_verticalSlider11_Shoulder1_sliderReleased()
{
    QByteArray sendData;
    sendData[0] = 11;
    sendData[1] = ui->verticalSlider11_Shoulder1->value()/10.0;

    std::cout << (unsigned char)(sendData[1])*10 << std::endl;
    m_SerialPort_A.write("INM");
    m_SerialPort_A.write(sendData);
    m_SerialPort_A.write("OOV");
}

// 脖子-俯仰
void MainWindow::on_verticalSlider12_Neck1_sliderReleased()
{
    QByteArray sendData;
    sendData[0] = 12;
    sendData[1] = ui->verticalSlider12_Neck1->value()/10.0;

    std::cout << (unsigned char)(sendData[1])*10 << std::endl;
    m_SerialPort_A.write("INM");
    m_SerialPort_A.write(sendData);
    m_SerialPort_A.write("OOV");
}

// 脖子-偏航
void MainWindow::on_verticalSlider13_Neck2_sliderReleased()
{
    QByteArray sendData;
    sendData[0] = 13;
    sendData[1] = ui->verticalSlider13_Neck2->value()/10.0;

    std::cout << (unsigned char)(sendData[1])*10 << std::endl;
    m_SerialPort_A.write("INM");
    m_SerialPort_A.write(sendData);
    m_SerialPort_A.write("OOV");
}

// Lean
void MainWindow::on_verticalSlider27_Lean_sliderReleased()
{
    QByteArray sendData;
    sendData[0] = 27;
    sendData[1] = ui->verticalSlider27_Lean->value()/10.0;

    std::cout << (unsigned char)(sendData[1])*10 << std::endl;
    m_SerialPort_A.write("INM");
    m_SerialPort_A.write(sendData);
    m_SerialPort_A.write("OOV");
}

// Rot
void MainWindow::on_verticalSlider28_Rot_sliderReleased()
{
    QByteArray sendData;
    sendData[0] = 28;
    sendData[1] = ui->verticalSlider28_Rot->value()/10.0;

    std::cout << (unsigned char)(sendData[1])*10 << std::endl;
    m_SerialPort_A.write("INM");
    m_SerialPort_A.write(sendData);
    m_SerialPort_A.write("OOV");
}


void MainWindow::on_pushButton_CloseHand_clicked()
{
    QByteArray sendData;
    sendData[0] = 100;
    sendData[1] = 0;

    std::cout << (unsigned char)(sendData[1])*10 << std::endl;
    m_SerialPort_A.write("INM");
    m_SerialPort_A.write(sendData);
    m_SerialPort_A.write("OOV");
}


void MainWindow::on_pushButton_OpenHand_clicked()
{
    QByteArray sendData;
    sendData[0] = 101;
    sendData[1] = 0;

    std::cout << (unsigned char)(sendData[1])*10 << std::endl;
    m_SerialPort_A.write("INM");
    m_SerialPort_A.write(sendData);
    m_SerialPort_A.write("OOV");
}


void MainWindow::on_pushButton_Reset_clicked()
{
    QByteArray sendData;
    sendData[0] = 102;
    sendData[1] = 0;

    std::cout << (unsigned char)(sendData[1])*10 << std::endl;
    m_SerialPort_A.write("INM");
    m_SerialPort_A.write(sendData);
    m_SerialPort_A.write("OOV");
}



void MainWindow::on_verticalSlider12_Neck1_sliderMoved(int position)
{
//    QByteArray sendData;
//    sendData[0] = 12;
//    sendData[1] = ui->verticalSlider12_Neck1->value()/10.0;

//    std::cout << (unsigned char)(sendData[1])*10 << std::endl;
//    m_SerialPort_A.write("INM");
//    m_SerialPort_A.write(sendData);
//    m_SerialPort_A.write("OOV");
}
