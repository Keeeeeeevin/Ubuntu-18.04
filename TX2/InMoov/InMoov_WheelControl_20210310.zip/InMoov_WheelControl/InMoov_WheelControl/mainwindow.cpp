#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTime>
#include <QTimer>
#include <QKeyEvent>
#include <iostream>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // ��������
    foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
    {
        QString s = info.portName();
        ui->comboBox_SerialPort->addItem(s);
    }
    ui->comboBox_SerialPort->addItem(QStringLiteral("Refresh"));
    ui->comboBox_SerialPort->addItem(QStringLiteral("clear"));

    //    QTimer *timer = new QTimer(this);
    //    QObject::connect(timer, SIGNAL(timeout()), this, SLOT(GetWheelTemperature()));
    //    timer->start(500);
}


MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::Start(unsigned char id)
{
    QByteArray sendData;
    sendData[0] = id;
    sendData[1] = 0x06;
    sendData[2] = 0x20;
    sendData[3] = 0x31;
    sendData[4] = 0x00;
    sendData[5] = 0x08;

    short ret1 = CRC16_MODBUS(sendData);

    sendData[6] = ret1>>8;
    sendData[7] = ret1 & 0xFF;

    SerialPort.write(sendData);

}


void MainWindow::Stop(unsigned char id)
{
    QByteArray sendData;
    sendData[0] = id;
    sendData[1] = 0x06;
    sendData[2] = 0x20;
    sendData[3] = 0x31;
    sendData[4] = 0x00;
    sendData[5] = 0x07;

    short ret1 = CRC16_MODBUS(sendData);

    sendData[6] = ret1>>8;
    sendData[7] = ret1 & 0xFF;

    SerialPort.write(sendData);
}


void MainWindow::SpeedMode(unsigned char id)
{
    QByteArray sendData;
    sendData[0] = id;
    sendData[1] = 0x06;
    sendData[2] = 0x20;
    sendData[3] = 0x32;
    sendData[4] = 0x00;
    sendData[5] = 0x03;

    short ret1 = CRC16_MODBUS(sendData);

    sendData[6] = ret1>>8;
    sendData[7] = ret1 & 0xFF;

    SerialPort.write(sendData);
}


void MainWindow::ForwardRight()
{
    short speed = ui->horizontalSlider_Speed->value();
    SetSpeed(WL, speed);

    QTime t;
    t.start();
    while(t.elapsed()<DT)
        QCoreApplication::processEvents();

    SetSpeed(WR, -speed*Ratio);
}


void MainWindow::ForwardLeft()
{
    short speed = ui->horizontalSlider_Speed->value();
    SetSpeed(WL, speed*Ratio);

    QTime t;
    t.start();
    while(t.elapsed()<DT)
        QCoreApplication::processEvents();

    SetSpeed(WR, -speed);
}


void MainWindow::SetSpeed(unsigned char id, short speed)
{
    QByteArray sendData;
    sendData[0] = id;
    sendData[1] = 0x06;
    sendData[2] = 0x20;
    sendData[3] = 0x3A;
    sendData[4] = speed >> 8;
    sendData[5] = speed & 0xFF;

    short ret1 = CRC16_MODBUS(sendData);

    sendData[6] = ret1>>8;
    sendData[7] = ret1 & 0xFF;

    SerialPort.write(sendData);
}



void MainWindow::keyPressEvent(QKeyEvent *ev)
{
    QTime t;
    t.start();
    while(t.elapsed()<DT)
        QCoreApplication::processEvents();

    short speed = ui->horizontalSlider_Speed->value();

    switch(ev->key())
    {
    case Qt::Key_W:
        on_pushButton_Forward_clicked();
        break;
    case Qt::Key_S:
        on_pushButton_Backward_clicked();
        break;
    case Qt::Key_A:
        on_pushButton_Left_clicked();
        break;
    case Qt::Key_D:
        on_pushButton_Right_clicked();
        break;
    case Qt::Key_Q:
        ForwardLeft();
        break;
    case Qt::Key_E:
        ForwardRight();
        break;
    case Qt::Key_F1:
        on_pushButton_Stop_clicked();
        break;
    case Qt::Key_F2:
        on_pushButton_Start_clicked();
        break;
    case Qt::Key_Plus:
        if(speed < 0) speed = 0;
        speed = (speed+5)*1.25;
        ui->horizontalSlider_Speed->setValue(speed);
        break;
    case Qt::Key_0:
        ui->horizontalSlider_Speed->setValue(0);
        break;
    case Qt::Key_1:
        ui->horizontalSlider_Speed->setValue(10);
        break;
    case Qt::Key_2:
        ui->horizontalSlider_Speed->setValue(20);
        break;
    case Qt::Key_3:
        ui->horizontalSlider_Speed->setValue(30);
        break;
    case Qt::Key_4:
        ui->horizontalSlider_Speed->setValue(40);
        break;
    case Qt::Key_5:
        ui->horizontalSlider_Speed->setValue(50);
        break;
    case Qt::Key_6:
        ui->horizontalSlider_Speed->setValue(60);
        break;
    case Qt::Key_7:
        ui->horizontalSlider_Speed->setValue(70);
        break;
    case Qt::Key_8:
        ui->horizontalSlider_Speed->setValue(80);
        break;
    case Qt::Key_9:
        ui->horizontalSlider_Speed->setValue(90);
        break;
    case Qt::Key_Minus:
        if(speed > 100) speed = 100;
        speed = 0.8*speed-5;
        ui->horizontalSlider_Speed->setValue(speed);
        break;
    default:
        break;
    }

    std::cout<< speed << std::endl;
}


void MainWindow::keyReleaseEvent(QKeyEvent *ev)
{
    if(ev->key() == Qt::Key_W || Qt::Key_S || Qt::Key_A || Qt::Key_D || Qt::Key_Q || Qt::Key_E)
    {
        SetSpeed(WL, 0);

        QTime t;
        t.start();
        while(t.elapsed()<DT)
            QCoreApplication::processEvents();

        SetSpeed(WR, 0);

        t.start();
        while(t.elapsed()<DT)
            QCoreApplication::processEvents();

        SetSpeed(WL, 0);

        t.start();
        while(t.elapsed()<DT)
            QCoreApplication::processEvents();

        SetSpeed(WR, 0);
    }
}


void MainWindow::GetWheelTemperature()
{
    QByteArray sendData;
    //    sendData[0] = id;
    sendData[0] = WL;
    sendData[1] = 0x03;
    sendData[2] = 0x20;
    sendData[3] = 0x26;
    sendData[4] = 0x00;
    sendData[5] = 0x0A;

    short ret1 = CRC16_MODBUS(sendData);

    sendData[6] = ret1>>8;
    sendData[7] = ret1 & 0xFF;

    SerialPort.write(sendData);
}


void MainWindow::on_pushButton_Forward_clicked()
{
    short speed = ui->horizontalSlider_Speed->value();
    SetSpeed(WL, speed);

    QTime t;
    t.start();
    while(t.elapsed()<DT)
        QCoreApplication::processEvents();

    SetSpeed(WR, -speed);
}


void MainWindow::on_pushButton_Backward_clicked()
{
    short speed = ui->horizontalSlider_Speed->value();
    SetSpeed(WL, -speed);

    QTime t;
    t.start();
    while(t.elapsed()<DT)
        QCoreApplication::processEvents();

    SetSpeed(WR, speed);
}


void MainWindow::on_pushButton_Left_clicked()
{
    short speed = ui->horizontalSlider_Speed->value();
    SetSpeed(WL, -speed*Ratio);

    QTime t;
    t.start();
    while(t.elapsed()<DT)
        QCoreApplication::processEvents();

    SetSpeed(WR, -speed*Ratio);
}


void MainWindow::on_pushButton_Right_clicked()
{
    short speed = ui->horizontalSlider_Speed->value();
    SetSpeed(WL, speed*Ratio);

    QTime t;
    t.start();
    while(t.elapsed()<DT)
        QCoreApplication::processEvents();

    SetSpeed(WR, speed*Ratio);
}


// CRCУ��
short MainWindow::CRC16_MODBUS(QByteArray sendData)
{
    unsigned short tmp = 0xFFFF;
    unsigned short ret1 = 0;

    for(int n = 0; n < 6; n++)
    {
        tmp = (unsigned char)(sendData[n]) ^ tmp; //���
        for(int i = 0;i < 8;i++)
        {
            if(tmp & 0x01)
            {
                tmp = tmp >> 1;
                tmp = tmp ^ 0xA001;
            }
            else
            {
                tmp = tmp >> 1;
            }
        }
    }
    ret1 = tmp >> 8;
    ret1 = ret1 | (tmp << 8);

    return ret1;
}


void MainWindow::on_pushButton_OpenSerialPort_clicked()
{
    if(ui->pushButton_OpenSerialPort->text() == QStringLiteral("Open Serial Port"))
    {
        QString str_port = ui->comboBox_SerialPort->currentText();

        SerialPort.setPortName("/dev/" + str_port);
        if(SerialPort.open(QIODevice::ReadWrite))
        {
            SerialPort.setBaudRate(115200);
            SerialPort.setDataBits(QSerialPort::Data8);
            SerialPort.setFlowControl(QSerialPort::NoFlowControl);
            SerialPort.setParity(QSerialPort::NoParity);
            SerialPort.setStopBits(QSerialPort::OneStop);
        }
        else
        {
            QMessageBox msgBox;
            msgBox.setText(QStringLiteral("Open Serial Port Failed"));
            msgBox.exec();
            return;
        }

        ui->pushButton_OpenSerialPort->setText(QStringLiteral("Close Serial Port"));
    }

    else if(ui->pushButton_OpenSerialPort->text() == QStringLiteral("Close Serial Port"))
    {
        SerialPort.close();
        ui->pushButton_OpenSerialPort->setText(QStringLiteral("Open Serial Port"));
    }
    else
    {
        return;
    }
}


void MainWindow::on_pushButton_Start_clicked()
{
    Start(WL);

    QTime t;
    t.start();
    while(t.elapsed()<DT)
        QCoreApplication::processEvents();

    Start(WR);
}


void MainWindow::on_pushButton_Stop_clicked()
{
    Stop(WL);

    QTime t;
    t.start();
    while(t.elapsed()<DT)
        QCoreApplication::processEvents();

    Stop(WR);
}


void MainWindow::on_pushButton_Speed_Mode_clicked()
{
    SpeedMode(WL);

    QTime t;
    t.start();
    while(t.elapsed()<DT)
        QCoreApplication::processEvents();

    SpeedMode(WR);
}


void MainWindow::on_comboBox_SerialPort_activated(const QString &arg1)
{
    if(arg1 == QStringLiteral("refresh"))
    {
        ui->comboBox_SerialPort->clear();

        // ��������
        foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
        {
            QString s = info.portName();
            ui->comboBox_SerialPort->addItem(s);
        }
        ui->comboBox_SerialPort->addItem(QStringLiteral("refresh"));
        ui->comboBox_SerialPort->addItem(QStringLiteral("clear"));
    }
    else if(arg1 == QStringLiteral("clear"))
    {
        ui->comboBox_SerialPort->clear();
        ui->comboBox_SerialPort->addItem(QStringLiteral("refresh"));
        ui->comboBox_SerialPort->addItem(QStringLiteral("clear"));
    }
}
