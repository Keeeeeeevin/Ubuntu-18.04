#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtSerialPort/QSerialPortInfo>
#include <QSerialPort>
#include <QMessageBox>

#define WL 1
#define WR 3
#define DT 10
#define Ratio 0.75

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void Start(unsigned char id);
    void Stop(unsigned char id);
    void SpeedMode(unsigned char id);
    void SetSpeed(unsigned char id, short speed);
    void ForwardRight();
    void ForwardLeft();

    short CRC16_MODBUS(QByteArray sendData);

protected:
    virtual void keyPressEvent(QKeyEvent *ev);
    virtual void keyReleaseEvent(QKeyEvent *ev);

private slots:

    void GetWheelTemperature();


    void on_pushButton_OpenSerialPort_clicked();

    void on_pushButton_Start_clicked();
    void on_pushButton_Stop_clicked();
    void on_pushButton_Speed_Mode_clicked();

    void on_pushButton_Forward_clicked();
    void on_pushButton_Backward_clicked();
    void on_pushButton_Left_clicked();
    void on_pushButton_Right_clicked();

    void on_comboBox_SerialPort_activated(const QString &arg1);

private:
    Ui::MainWindow *ui;
    QSerialPort SerialPort;
};

#endif // MAINWINDOW_H
